__all__ = ['get_linear_gradient']

from .main import get_linear_gradient
